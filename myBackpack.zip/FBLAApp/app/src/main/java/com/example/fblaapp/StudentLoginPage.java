package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class StudentLoginPage extends AppCompatActivity {
    EditText username, password;
    Button login, signup;
    DatabaseHelper DB;
    String userPass, userRole;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login_page);

// Find the UI components by ID and assign them to the corresponding variables
        username = findViewById(R.id.UsernameLogin);
        password = findViewById(R.id.PasswordLogin);
        login = findViewById(R.id.LoginButton);
        signup = findViewById(R.id.SignUpButton);

// Initialize the DatabaseHelper object
        DB = new DatabaseHelper(this);

// Add text change listeners to the username and password EditText fields
// These listeners will check if the text in the EditText fields has changed and enable/disable the login button accordingly
        username.addTextChangedListener(loginTextWatcher);
        password.addTextChangedListener(loginTextWatcher);

// Set an OnClickListener for the login button
        login.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String checkusername = username.getText().toString();
                String checkpassword = password.getText().toString();
                if (DB.userExists(checkusername) == true) {
                    Cursor cursor = DB.getPassword(checkusername);
                    cursor.moveToFirst();
                    if (cursor.moveToFirst()) {
                        userPass = cursor.getString(cursor.getColumnIndex("password"));
                    }
                    boolean isPasswordMatched = PasswordUtils.verifyPassword(checkpassword, userPass);
                    if (isPasswordMatched) {
                        Toast.makeText(StudentLoginPage.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), TeacherHome.class);
                        Bundle b = new Bundle();
                        b.putString("username", checkusername);
                        intent.putExtras(b);
                        startActivity(intent);
                    } else {
                        Toast.makeText(StudentLoginPage.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    Toast.makeText(StudentLoginPage.this,"Login Failed",Toast.LENGTH_SHORT).show();
                }
            }
        });
        // Check if user clicks on create new account button, if so, start the CreateAccPage activity
        signup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent CreateAccPage = new Intent(StudentLoginPage.this, CreateAccPage.class);
                startActivity(CreateAccPage);
            }
        });
    }
    // Check if any of the text boxes are empty, if so, make the log in button unavailable
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String emailAddInput = username.getText().toString().trim();
            String nameInput = password.getText().toString().trim();
            login.setEnabled(!emailAddInput.isEmpty() && !nameInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
}