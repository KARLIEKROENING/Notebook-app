package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ViewMyAccount extends AppCompatActivity {
    TextView Email, FullName, Grade, Username, Password, School;
    DatabaseHelper DB;
    Bundle b;
    Button toggle, EditAccount, CopyrightStatement;
    Boolean showornah;
    public void Show(){
        Password.setVisibility(View.VISIBLE);
    }
    public void Hide(){
        Password.setVisibility(View.INVISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_account);
        showornah = false;
        toggle = findViewById(R.id.showNHideButton);
        EditAccount = findViewById(R.id.EditAccountInfo);
        CopyrightStatement = findViewById(R.id.CopyrightStatement);
        Email = findViewById(R.id.email);
        FullName = findViewById(R.id.name);
        Grade = findViewById(R.id.Grade);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        School = findViewById(R.id.School);
        b = getIntent().getExtras();
        String username = b.getString("name");
        DB = new DatabaseHelper(this);
        Cursor cursor = DB.getDataNameAll(username);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                Email.setText("Email: "+ cursor.getString(0));
                FullName.setText("Full Name: "+ cursor.getString(1));
                Username.setText("Username: " + cursor.getString(2));
                Password.setText("Password: " + cursor.getString(3));
                Grade.setText("Grade: " + cursor.getString(4));
                School.setText("School: " + cursor.getString(5));

            }
        }
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(showornah == false){
                    Show();
                    showornah = true;
                }
                else{
                    Hide();
                    showornah = false;
                }

            }
        });
        EditAccount.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent EditAccountInfo = new Intent(ViewMyAccount.this,EditAccount.class);
                Bundle b = new Bundle();
                b.putString("name",username);
                EditAccountInfo.putExtras(b);
                startActivity(EditAccountInfo);
            }
        });
        CopyrightStatement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent CopyrightStatement = new Intent(ViewMyAccount.this,CopyrightStatement.class);
                startActivity(CopyrightStatement);
            }
        });

    }
}