package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewStudent extends AppCompatActivity {
    ArrayList<String> namelst, gradelst;
    DatabaseHelper DB;
    Button EditStudents;
    Bundle b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);
        Intent intent = getIntent();
        String code = intent.getStringExtra("code");
        String username = intent.getStringExtra("username");
        Log.i("The code is",code);
        DB = new DatabaseHelper(this);
        EditStudents = findViewById(R.id.edit_students);
        b = getIntent().getExtras();
        namelst = new ArrayList<>();
        gradelst = new ArrayList<>();
        storeDataInArrays(code);
        RecyclerView recyclerView = findViewById(R.id.RecyclerView);
        CustomAdapter customAdapter = new CustomAdapter(ViewStudent.this, namelst, gradelst);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewStudent.this));
        EditStudents.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent CheckStudentsEdit = new Intent(ViewStudent.this, CheckStudentsEdit.class);
                b.putString("code", code);
                b.putString("username",username);
                CheckStudentsEdit.putExtras(b);
                startActivity(CheckStudentsEdit);
            }
        });
    }
    void storeDataInArrays(String code){
        Cursor cursor = DB.readAllData(code);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                gradelst.add(cursor.getString(5));
            }
        }
    }
}