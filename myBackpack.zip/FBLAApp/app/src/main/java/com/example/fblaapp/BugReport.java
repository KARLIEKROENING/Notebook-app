package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class BugReport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bug_report);
        Spinner categories = findViewById(R.id.category);
        DatabaseHelper DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        String username = b.getString("name");
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.bug_categories, R.layout.spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown);
        categories.setAdapter(adapter);
        Button submit = findViewById(R.id.submit);
        TextView descriptionet = findViewById(R.id.descriptionet);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] TO_EMAILS = {"mybackpackdevs@gmail.com"};
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL,TO_EMAILS);
                intent.putExtra(Intent.EXTRA_SUBJECT,"Bug: "+categories.getSelectedItem().toString());
                intent.putExtra(Intent.EXTRA_TEXT, descriptionet.getText().toString());
                startActivity(Intent.createChooser(intent, "Choose one application."));
                //Intent homePage = new Intent(BugReport.this, TeacherHome.class);
                //Bundle b = new Bundle();
                //b.putString("username", DB.getDataUserName(username));
                //homePage.putExtras(b);
                //startActivity(homePage);
            }
        });

    }
}