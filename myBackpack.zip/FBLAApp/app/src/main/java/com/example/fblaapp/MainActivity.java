package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

// This class extends AppCompatActivity and represents the main activity of the application.
public class MainActivity extends AppCompatActivity {
    // The onCreate() method is called when the activity is created.
    DatabaseHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to activity_main.xml layout file.
        setContentView(R.layout.activity_main);
        // Get references to the three buttons defined in the layout file.
        Button studentLogin = findViewById(R.id.studentLogin);
        Button signUp = findViewById(R.id.signUp);
        DB = new DatabaseHelper(this);
        DB.dropTable();
        //DB.clearDatabase("Awards");
        //DB.clearDatabase("Classes");
        //DB.clearDatabase("UserData2");
        //DB.clearDatabase("Volunteer");

        // Set up a click listener for the "studentLogin" button.
        studentLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // Create a new Intent object to start the StudentLoginPage activity.
                Intent studentLoginPage = new Intent(MainActivity.this, StudentLoginPage.class);
                // Start the StudentLoginPage activity.
                startActivity(studentLoginPage);

            }
        });


        // Set up a click listener for the "signUp" button.
        signUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // Create a new Intent object to start the CreateAccPage activity.
                Intent signUp = new Intent(MainActivity.this, CreateAccPage.class);
                // Start the CreateAccPage activity.
                startActivity(signUp);
            }
        });

    }
}