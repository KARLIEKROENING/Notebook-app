package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter4 extends RecyclerView.Adapter<CustomAdapter4.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList pastEventslst;
    private RecyclerViewClickListener listener;
    private String selectedEventName;
    CustomAdapter4(Context context, ArrayList pastEventslst, RecyclerViewClickListener listener){
        this.context = context;
        this.pastEventslst = pastEventslst;
        this.listener = listener;

    }
    public String getSelectedEventName(){
        return selectedEventName;
    }
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.card_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter4.MyViewHolder holder, int position) {
        holder.pastEvent.setText(String.valueOf(pastEventslst.get(position)));
    }

    @Override
    public int getItemCount() {
        return pastEventslst.size();
    }

    public interface RecyclerViewClickListener{
        void onClick(View v, int position);
    }
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView pastEvent;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            pastEvent = itemView.findViewById(R.id.pastEvent);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            selectedEventName = pastEventslst.get(getAdapterPosition()).toString();
            listener.onClick(view,getAdapterPosition());
        }
    }
}
