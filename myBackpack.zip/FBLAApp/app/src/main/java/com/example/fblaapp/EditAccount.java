package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditAccount extends AppCompatActivity {
    EditText EditEmail, EditFullName, EditGrade, EditUsername, EditPassword, EditSchool;
    Button confirm;
    Bundle b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_account_info);
        EditEmail = findViewById(R.id.EditEmail);
        EditFullName = findViewById(R.id.EditFullName);
        EditGrade = findViewById(R.id.EditGrade);
        EditUsername = findViewById(R.id.EditUsername);
        EditPassword = findViewById(R.id.EditPassword);
        EditSchool = findViewById(R.id.EditSchool);
        confirm = findViewById(R.id.confirm);
        DatabaseHelper db = new DatabaseHelper(this);
        b = getIntent().getExtras();
        String data = b.getString("name");
        Log.d("the name is ",data);
        confirm.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String Email = EditEmail.getText().toString();
                String FullName = EditFullName.getText().toString();
                String Grade = EditGrade.getText().toString();
                String Username = EditUsername.getText().toString();
                String Password = EditPassword.getText().toString();
                String School = EditSchool.getText().toString();
                db.editUserData(data,Email, FullName,Grade,Username,Password,School);
                Intent Login = new Intent(EditAccount.this, MainActivity.class);
                startActivity(Login);

            }
        });

    }
}