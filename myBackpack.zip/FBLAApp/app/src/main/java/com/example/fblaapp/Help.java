package com.example.fblaapp;

import static com.example.fblaapp.Message.SENT_BY_BOT;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Help extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView welcomeTextView;
    EditText messageEditText;
    ImageButton sendButton;
    ArrayList<Message> messageList;
    MessageAdapter messageAdapter;
    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");
    OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        messageList = new ArrayList<>();

        recyclerView = findViewById(R.id.recycler_view);
        welcomeTextView = findViewById(R.id.welcome_text);
        messageEditText = findViewById(R.id.message_edit_text);
        sendButton = findViewById(R.id.send_btn);

        //setup recycler view
        messageAdapter = new MessageAdapter(messageList);
        recyclerView.setAdapter(messageAdapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        recyclerView.setLayoutManager(llm);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gemini model = new Gemini();
                String query = messageEditText.getText().toString();
                addToChat(query,Message.SENT_BY_ME);
                messageEditText.setText("");
                model.getResponse(query+"\n" +
                        "\n" +
                        "\n" +
                        "MyBackpack Documentation\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Stephen Hung, Shaan Mistry, Zhe Wang\n" +
                        "\n" +
                        "Ruben S. Ayala High School\n" +
                        "\n" +
                        "2023-24\n" +
                        "Running the Application\n" +
                        "\n" +
                        "This mobile application was developed in Java using Android Studio. Our app can be downloaded and run across all Android devices by using the Google Play Store application.\n" +
                        "\n" +
                        "Planning Process\n" +
                        "We began our planning process by researching the requirements and prompt for this year’s Mobile Application Development event\n" +
                        "We conducted surveys with students in our high school to determine features that they would want to see in an app that showcases their portfolio\n" +
                        "Before we began programming our app, we collectively set deadlines for the app using a shared Google Calendar, where we decided that we would meet once a week during December for the planning process and then ramp up to two weekly meetings during January and February as we coded.\n" +
                        "We wanted a way to professionally design each page of the app to make the process more efficient when it came time to outline what each page would look like. Thus, we utilized an online software named Figma to create a wireframe.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "During each meeting, we set specific goals for pages we wanted to complete and at the end of each meeting, we reviewed our progress and determined if another meeting was needed on the designated page to improve its performance.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Screenshots\n" +
                        "Onboarding Page\n" +
                        "When the user launches MyBackpack, this will be the first page that they are prompted with. This initial page showcases the app name, logo, and slogan. The user has the option to login to a previously made account or create a new account.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Create Account Page\n" +
                        "On the create account page, users are required to enter an email, name, username, password, grade, and school.\n" +
                        "Once entering the information, users can click the “Sign Up” button to create their account \n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Login Page\n" +
                        "If users already have an account, they can use the “Sign In” page, where they will be prompted to enter their username and password. Once entering the information, they can click “Sign In” to open their account.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Home Page\n" +
                        "The home page of MyBackpack is where users will find buttons that lead to each individual part of their portfolio. Each button has an icon that represents what the user will view when clicking on it. For example, the button that has an icon showing a teacher instructing a class is where users can add and view classes they have taken. \n" +
                        "The home page also features a button in the top right corner that allows the user to logout of their account, bringing them back to the onboarding page.\n" +
                        "\n" +
                        "View Other Students Page\n" +
                        "The view other students page allows each student to view the portfolio of other students who have created their account. Each student is shown with their grade level and a button to “View Profile,” which takes them to the resume of the designated student.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Other Student Page\n" +
                        "When the user clicks “View Profile” for a student from the View Other Students Page, they are brought to their portfolio, where the user can export the student’s portfolio as a PDF or share it via Instagram.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "My Awards Page\n" +
                        "\n" +
                        "\n" +
                        "Add Awards Page\n" +
                        "My Classes Page\n" +
                        "Add Classes Page\n" +
                        "My Volunteer Experience Page\n" +
                        "Add Volunteer Experience Page\n" +
                        "My Clubs Page\n" +
                        "Add Clubs Page\n" +
                        "Other Extracurriculars Page\n" +
                        "Add Other Extracurriculars Page\n" +
                        "My Work Experience Page\n" +
                        "Add Work Experience Page\n" +
                        "My Test Scores Page\n" +
                        "Add Test Scores Page\n" +
                        "Help Page (Chatbot)\n" +
                        "Bug Reporting Page\n" +
                        "View My Account Page\n" +
                        "Edit Account Information Page\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n", new ResponseCallback() {
                    @Override
                    public void onResponse(String response) {
                        addToChat(response, Message.SENT_BY_BOT);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        Toast.makeText(Help.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });
                welcomeTextView.setVisibility(View.GONE);
            }
        });
    }

    void addToChat(String message,String sentBy){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                messageList.add(new Message(message,sentBy));
                messageAdapter.notifyDataSetChanged();
                recyclerView.smoothScrollToPosition(messageAdapter.getItemCount());
            }
        });
    }

    void addResponse(String response){
        messageList.remove(messageList.size()-1);
        addToChat(response, SENT_BY_BOT);
    }


}




















