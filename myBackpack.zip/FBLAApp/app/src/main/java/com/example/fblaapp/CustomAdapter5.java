package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter5 extends RecyclerView.Adapter<CustomAdapter5.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, yearlst, gradelst;
    CustomAdapter5(Context context, ArrayList yearlst, ArrayList namelst, ArrayList gradelst){
        this.context = context;
        this.namelst = namelst;
        this.yearlst = yearlst;
        this.gradelst = gradelst;
    }

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row4,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter5.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.yearid.setText(String.valueOf(yearlst.get(position)));
        holder.gradeid.setText(String.valueOf(gradelst.get(position)));
    }

    @Override
    public int getItemCount() {
        return namelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView yearid, nameid, gradeid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            yearid = itemView.findViewById(R.id.yearid);
            nameid = itemView.findViewById(R.id.nameid);
            gradeid = itemView.findViewById(R.id.gradeid);
        }

    }
}
