package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter6 extends RecyclerView.Adapter<CustomAdapter6.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList datelst, organizationlst, descriptionlst, hourslst;
    CustomAdapter6(Context context, ArrayList datelst, ArrayList organizationlst, ArrayList descriptionlst, ArrayList hourslst){
        this.context = context;
        this.datelst = datelst;
        this.organizationlst = organizationlst;
        this.descriptionlst = descriptionlst;
        this.hourslst = hourslst;
    }

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row5,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter6.MyViewHolder holder, int position) {
        holder.dateid.setText(String.valueOf(datelst.get(position)));
        holder.organizationid.setText(String.valueOf(organizationlst.get(position)));
        holder.descriptionid.setText(String.valueOf(descriptionlst.get(position)));
        holder.hoursid.setText(String.valueOf(hourslst.get(position)));
    }

    @Override
    public int getItemCount() {
        return datelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView dateid, organizationid, descriptionid, hoursid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dateid = itemView.findViewById(R.id.dateid);
            organizationid = itemView.findViewById(R.id.organizationid);
            descriptionid = itemView.findViewById(R.id.descriptionid);
            hoursid = itemView.findViewById(R.id.hoursid);
        }

    }
}
