package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewAwards extends AppCompatActivity {
    DatabaseHelper DB;
    Button addAwards;
    ArrayList<String> datelst, namelst, levellst, individualteamlst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_awards);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addAwards = findViewById(R.id.addAwards);
        addAwards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editAwardsPage = new Intent(ViewAwards.this, AddAwards.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
        datelst = new ArrayList<>();
        namelst = new ArrayList<>();
        levellst = new ArrayList<>();
        individualteamlst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter3 customAdapter1 = new CustomAdapter3(ViewAwards.this, datelst, namelst, levellst, individualteamlst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewAwards.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllAwards(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                datelst.add(cursor.getString(2));
                levellst.add(cursor.getString(3));
                individualteamlst.add(cursor.getString(4));
            }
        }
    }

}