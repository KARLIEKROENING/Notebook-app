package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewTestScores extends AppCompatActivity {
    DatabaseHelper DB;
    Button addTestScores;
    ArrayList<String> namelst, datelst, gradelst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_test_scores);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addTestScores = findViewById(R.id.addTestScores);
        addTestScores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editAwardsPage = new Intent(ViewTestScores.this, AddTestScores.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
        namelst = new ArrayList<>();
        datelst = new ArrayList<>();
        gradelst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter10 customAdapter1 = new CustomAdapter10(ViewTestScores.this, namelst, datelst, gradelst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewTestScores.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllTestScores(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                datelst.add(cursor.getString(2));
                gradelst.add(cursor.getString(3));
            }
        }
    }

}