package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Calendar;
import java.text.SimpleDateFormat;

// This class extends AppCompatActivity and represents the activity for creating a new event.
public class AddExtracurriculars extends AppCompatActivity {
    private EditText etSelectDateStarted, etSelectDateEnded, etName, etPosition, etDescription;
    private Button createButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getExtras();
        String name = b.getString("name");
        setContentView(R.layout.activity_add_extracurriculars);
        etSelectDateStarted = findViewById(R.id.SelectDateIdStarted);
        etSelectDateEnded = findViewById(R.id.SelectDateIdEnded);
        etName = findViewById(R.id.nameid);
        etPosition = findViewById(R.id.positionid);
        etDescription = findViewById(R.id.descriptionid);
        createButton = findViewById(R.id.addEC);
        etSelectDateEnded.addTextChangedListener(loginTextWatcher);
        etSelectDateStarted.addTextChangedListener(loginTextWatcher);
        etName.addTextChangedListener(loginTextWatcher);
        etPosition.addTextChangedListener(loginTextWatcher);
        etDescription.addTextChangedListener(loginTextWatcher);
        DatabaseHelper DB = new DatabaseHelper(this);
        final Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        etSelectDateStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog = new DatePickerDialog(AddExtracurriculars.this, R.style.TimePickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        i1 = i1 + 1;
                        String date = ""+i + String.format("%02d", i1) + String.format("%02d", i2);

                        etSelectDateStarted.setText(formatDate(date));

                    }
                }, year, month, day);
                dialog.show();
            }
        });
        etSelectDateEnded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog = new DatePickerDialog(AddExtracurriculars.this, R.style.TimePickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        i1 = i1 + 1;
                        String date = ""+i + String.format("%02d", i1) + String.format("%02d", i2);

                        etSelectDateEnded.setText(formatDate(date));

                    }
                }, year, month, day);
                dialog.show();
            }
        });
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String DateDuration = etSelectDateStarted.getText().toString()+"-"+etSelectDateEnded.getText().toString();
                String Name = etName.getText().toString();
                String Position = etPosition.getText().toString();
                String Description = etDescription.getText().toString();
                Boolean checkinsertdata = DB.insertExtracurricularData(name, Name, Position, DateDuration, Description);
                if (checkinsertdata == true) {
                    Toast.makeText(AddExtracurriculars.this, "Extracurricular Creation Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddExtracurriculars.this, "Extracurricular Creation Failed", Toast.LENGTH_SHORT).show();
                }
                Intent editAwardsPage = new Intent(AddExtracurriculars.this, TeacherHome.class);
                Bundle b = new Bundle();
                b.putString("username", DB.getDataUserName(name));
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String SelectDate = etSelectDateEnded.getText().toString().trim();
            String SelectDate1 = etSelectDateStarted.getText().toString().trim();
            String Name = etName.getText().toString().trim();
            String Position = etPosition.getText().toString().trim();
            String Description = etDescription.getText().toString().trim();
            createButton.setEnabled(!SelectDate.isEmpty() && !SelectDate1.isEmpty() &&!Name.isEmpty()&& !Position.isEmpty() && !Description.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
    public static String formatDate(String dateString) {
        if (dateString.length() != 8) {
            throw new IllegalArgumentException("Invalid date format. Please provide a string in the format YYYYMMDD.");
        }

        int year = Integer.parseInt(dateString.substring(0, 4));
        int month = Integer.parseInt(dateString.substring(4, 6));
        int day = Integer.parseInt(dateString.substring(6));

        return String.format("%d/%d/%d", month, day, year);
    }

}

