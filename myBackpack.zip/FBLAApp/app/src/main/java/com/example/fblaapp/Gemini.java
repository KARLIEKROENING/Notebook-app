package com.example.fblaapp;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.Executor;

public class Gemini {
    public void getResponse(String query, ResponseCallback callback){
        GenerativeModelFutures model = getModel();
        Content content = new Content.Builder().addText(query).build();
        Executor executor = Runnable::run;
        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);
        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                String resultText = result.getText();
                callback.onResponse(resultText);
                System.out.println(resultText);
            }

            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                callback.onError(t);
            }
        }, executor);
    }
    private GenerativeModelFutures getModel(){
        String apiKey = "AIzaSyAMAvmm2KBoh0J6FJcarqqvgJyYdNv8p7k";
        GenerativeModel gm  = new GenerativeModel("gemini-pro",apiKey);
        return GenerativeModelFutures.from(gm);
    }
}
