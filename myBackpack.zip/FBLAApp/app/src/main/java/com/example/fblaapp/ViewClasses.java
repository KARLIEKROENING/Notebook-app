package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewClasses extends AppCompatActivity {

    DatabaseHelper DB;
    Button addClass;
    ArrayList<String> yearlst, namelst, gradelst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_classes);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addClass = findViewById(R.id.addClass);
        addClass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editAwardsPage = new Intent(ViewClasses.this, AddClasses.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
        yearlst = new ArrayList<>();
        namelst = new ArrayList<>();
        gradelst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter5 customAdapter1 = new CustomAdapter5(ViewClasses.this, yearlst, namelst, gradelst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewClasses.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllClasses(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                yearlst.add(cursor.getString(2));
                gradelst.add(cursor.getString(3));
            }
        }
    }
}