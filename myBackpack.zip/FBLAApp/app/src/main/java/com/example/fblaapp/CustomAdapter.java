package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, gradelst;
    CustomAdapter(Context context, ArrayList namelst, ArrayList gradelst){
        this.context = context;
        this.namelst = namelst;
        this.gradelst = gradelst;

    }
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.gradeid.setText(String.valueOf(gradelst.get(position)));
    }

    @Override
    public int getItemCount() {
        return namelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameid, gradeid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameid = itemView.findViewById(R.id.nameid);
            gradeid = itemView.findViewById(R.id.gradeid);
        }

    }
}
