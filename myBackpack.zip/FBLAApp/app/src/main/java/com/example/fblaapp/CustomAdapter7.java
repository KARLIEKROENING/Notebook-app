package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter7 extends RecyclerView.Adapter<CustomAdapter7.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, positionlst, datelst, descriptionlst;
    CustomAdapter7(Context context, ArrayList namelst, ArrayList positionlst, ArrayList datelst, ArrayList descriptionlst){
        this.context = context;
        this.namelst = namelst;
        this.positionlst = positionlst;
        this.datelst = datelst;
        this.descriptionlst = descriptionlst;
    }

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row6,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter7.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.positionid.setText(String.valueOf(positionlst.get(position)));
        holder.dateid.setText(String.valueOf(datelst.get(position)));
        holder.descriptionid.setText(String.valueOf(descriptionlst.get(position)));
    }

    @Override
    public int getItemCount() {
        return datelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameid, positionid, dateid, descriptionid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameid = itemView.findViewById(R.id.nameid);
            positionid = itemView.findViewById(R.id.positionid);
            dateid = itemView.findViewById(R.id.dateid);
            descriptionid = itemView.findViewById(R.id.descriptionid);
        }

    }
}
