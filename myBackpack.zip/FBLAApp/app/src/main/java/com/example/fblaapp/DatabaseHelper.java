package com.example.fblaapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context context) {
        super(context, "database", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create Table UserData2(email TEXT, name TEXT, username TEXT, password TEXT, grade TEXT, school TEXT)");
        sqLiteDatabase.execSQL("create Table Awards(username TEXT, name TEXT, dateWon TEXT, level TEXT, individualorteam TEXT)");
        sqLiteDatabase.execSQL("create Table Classes(username TEXT, name TEXT, year TEXT, grade TEXT)");
        sqLiteDatabase.execSQL("create Table Volunteer(username TEXT, date TEXT, organization TEXT, description TEXT, hours TEXT)");
        sqLiteDatabase.execSQL("create Table Clubs(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT)");
        sqLiteDatabase.execSQL("create Table Extracurriculars(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT)");
        sqLiteDatabase.execSQL("create Table Work(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT, partorfull TEXT, paidorunpaid TEXT)");
        sqLiteDatabase.execSQL("create Table TestScores(username TEXT, name TEXT, date TEXT, grade TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop Table if exists UserData2");
        sqLiteDatabase.execSQL("drop Table if exists Awards");
    }
    public void dropTable(){
        SQLiteDatabase DB = this.getWritableDatabase();
        //DB.execSQL("create Table TestScores(username TEXT, name TEXT, date TEXT, grade TEXT)");
        //DB.execSQL("create Table Work(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT, partorfull TEXT, paidorunpaid TEXT)");
        //DB.execSQL("create Table Extracurriculars(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT)");
        //DB.execSQL("drop Table if exists UserData2");
        //DB.execSQL("create Table Clubs(username TEXT, name TEXT, position TEXT, date TEXT, description TEXT)");
        //DB.execSQL("create Table Classes(username TEXT, name TEXT, year TEXT, grade TEXT)");
        //DB.execSQL("create Table Awards(username TEXT, name TEXT, dateWon TEXT, level TEXT, individualorteam TEXT)");
        //DB.execSQL("create Table Volunteer(username TEXT, date TEXT, organization TEXT, description TEXT, hours TEXT)");
        //DB.execSQL("create Table UserData2(email TEXT, name TEXT, username TEXT, password TEXT, grade TEXT, school TEXT)");
    }

    public Boolean insertuserdata(String email, String name, String username, String password, String grade, String school) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);
        contentValues.put("name", name);
        String encryptedPassword = PasswordUtils.encryptPassword(password);
        contentValues.put("username", username);
        contentValues.put("password", encryptedPassword);
        contentValues.put("grade", grade);
        contentValues.put("school",school);
        long result = DB.insert("UserData2", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean insertAwardData(String userName, String name, String date, String level, String individualOrTeam) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("dateWon", date);
        contentValues.put("level", level);
        contentValues.put("individualorteam", individualOrTeam);
        long result = DB.insert("Awards", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertClassesData(String userName, String name, String year, String grade) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("year", year);
        contentValues.put("grade", grade);
        long result = DB.insert("Classes", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertVolunteerData(String userName, String date, String organization, String description, String hours) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("date", date);
        contentValues.put("organization", organization);
        contentValues.put("description",description);
        contentValues.put("hours", hours);
        long result = DB.insert("Volunteer", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertClubData(String userName, String name, String position, String date, String description) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("position", position);
        contentValues.put("date",date);
        contentValues.put("description", description);
        long result = DB.insert("Clubs", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertExtracurricularData(String userName, String name, String position, String date, String description) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("position", position);
        contentValues.put("date",date);
        contentValues.put("description", description);
        long result = DB.insert("Extracurriculars", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertWorkData(String userName, String name, String position, String date, String description, String partorfull, String paidorunpaid) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("position", position);
        contentValues.put("date",date);
        contentValues.put("description", description);
        contentValues.put("partorfull", partorfull);
        contentValues.put("paidorunpaid",paidorunpaid);
        long result = DB.insert("Work", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public Boolean insertTestScoreData(String userName, String name, String date, String grade) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("name", name);
        contentValues.put("date", date);
        contentValues.put("grade",grade);
        long result = DB.insert("TestScores", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
    public void deleteUser(String name){
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.delete("UserData2","name=?",new String[]{name});
    }

    public void clearDatabase(String TABLE_NAME) {
        SQLiteDatabase DB = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + TABLE_NAME;
        DB.execSQL(clearDBQuery);
    }

    public Boolean checkusernamepassword(String username, String password, String role) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("select * from UserData2 where username=? and password=? and role=?", new String[]{username, password, role});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String getDataName(String username) {
        String response = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from UserData2 where username = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(0);
                String name = cursor.getString(1);
                String grade = cursor.getString(4);
                String school = cursor.getString(5);
                // Do something with the retrieved data
                response += name;
            } while (cursor.moveToNext());
        }
        return response;
    }
    public String getDataUserName(String name) {
        String response = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from UserData2 where name = ?", new String[]{name});
        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(0);
                String username = cursor.getString(2);
                String grade = cursor.getString(4);
                String school = cursor.getString(5);
                // Do something with the retrieved data
                response += username;
            } while (cursor.moveToNext());
        }
        return response;
    }

    Cursor getDataNameAll(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM UserData2 WHERE name = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllAwards(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Awards WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllClasses(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Classes WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllVolunteer(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Volunteer WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllClubs(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Clubs WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllExtracurriculars(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Extracurriculars WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllWork(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM Work WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }
    Cursor getDataNameAllTestScores(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM TestScores WHERE username = ?";
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{name});
        }
        return cursor;
    }

    Cursor readAllData(String code) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM UserData2 WHERE code = ? AND role != 'Teacher' ORDER BY name ASC ";
        Cursor cursor = db.rawQuery(query, new String[]{code});
        return cursor;
    }
    Cursor readAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM UserData2 ORDER BY name ASC ";
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }



    Cursor readAllDataSortGrade() {
        String query = "SELECT * FROM UserData2 ORDER BY CAST(grade AS INTEGER) DESC, name ASC";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }


    Cursor readAllDataByGrade(String grade) {
        String query = "SELECT * FROM UserData2 WHERE grade=?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{grade});
        }
        return cursor;
    }

    Cursor getCode(String username) {
        String query = "SELECT code FROM UserData2 WHERE username = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }
    Cursor getPassword(String username) {
        String query = "SELECT password FROM UserData2 WHERE username = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, new String[]{username});
        }
        return cursor;
    }


    void updatePoints(String name, int points) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("points", "points + " + points);
        db.execSQL("UPDATE UserData2 SET points = points + ? WHERE name=?", new String[]{Integer.toString(points), name});
    }

    @SuppressLint("Range")
    int getEventHours(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        int hours = 0;
        if (db != null) {
            Cursor cursor = db.rawQuery("SELECT duration FROM EventData WHERE name = ?", new String[]{name});
            if (cursor.moveToFirst()) {
                hours = cursor.getInt(cursor.getColumnIndex("duration"));
            }
            cursor.close();
            db.close();
        }
        return hours;
    }

    public void editUserData(String oldName, String email, String newName, String grade, String username, String password, String school) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email",email);
        contentValues.put("name", newName);
        contentValues.put("grade", grade);
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("school", school);
        db.update("UserData2", contentValues, "name=?", new String[]{oldName});
        db.close();
    }
    public Boolean userExists(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM UserData2 WHERE username = ?", new String[]{username});
        boolean usernameExists = (cursor != null && cursor.getCount() > 0);
        if(cursor!=null){
            cursor.close();
        }
        return usernameExists;
    }
}
