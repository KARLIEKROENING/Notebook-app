package com.example.fblaapp;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Environment;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.fblaapp.databinding.ActivityViewProfile1Binding;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ViewProfile extends AppCompatActivity {
    final static int REQUEST_CODE = 1232;
    Bundle b;
    String name;
    DatabaseHelper DB;
    Button export, share;
    Cursor cursor, awards, testScores, clubs, classes, work, volunteer, extracurricular;
    TextView NameTextView, EmailTextView, GradeTextView, SchoolTextView, TestScoresTextView, ClubsTextView, AwardsTextView, ClassesTextView,WorkExperienceTextView, VolunteerExperienceTextView,ExtracurricularsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile1);
        b = getIntent().getExtras();
        askPermissions();
        name = b.getString("name");
        DB = new DatabaseHelper(this);
        export = findViewById(R.id.ExportButton);
        share = findViewById(R.id.ShareButton);
        cursor = DB.getDataNameAll(name);
        awards = DB.getDataNameAllAwards(name);
        testScores = DB.getDataNameAllTestScores(name);
        clubs = DB.getDataNameAllClubs(name);
        classes = DB.getDataNameAllClasses(name);
        work = DB.getDataNameAllWork(name);
        volunteer = DB.getDataNameAllVolunteer(name);
        extracurricular = DB.getDataNameAllExtracurriculars(name);
        NameTextView = findViewById(R.id.NameTextView);
        EmailTextView = findViewById(R.id.EmailTextView);
        GradeTextView = findViewById(R.id.GradeTextView);
        SchoolTextView = findViewById(R.id.SchoolTextView);
        TestScoresTextView = findViewById(R.id.TestScoresTextView);
        ClubsTextView = findViewById(R.id.ClubsTextView);
        AwardsTextView = findViewById(R.id.AwardsTextView);
        ClassesTextView = findViewById(R.id.ClassesTextView);
        WorkExperienceTextView = findViewById(R.id.WorkExperienceTextView);
        VolunteerExperienceTextView = findViewById(R.id.VolunteerExperienceTextView);
        ExtracurricularsTextView = findViewById(R.id.ExtracurricularsTextView);
        if (cursor.moveToFirst()) {
                // Do something with the retrieved data
                NameTextView.setText(cursor.getString(1));
                EmailTextView.setText(cursor.getString(0));
                GradeTextView.setText("Grade: "+cursor.getString(4));
                SchoolTextView.setText(cursor.getString(5));
        }
        if(awards.getCount() == 0){
            AwardsTextView.setText("N/A");
        }else{
            while(awards.moveToNext()){
                AwardsTextView.append(awards.getString(2)+" - "+awards.getString(1)+", "+awards.getString(3)+", "+awards.getString(4)+"\n");
            }
        }
        if(testScores.getCount() == 0){
            TestScoresTextView.setText("N/A");
        }else{
            while(testScores.moveToNext()){
                TestScoresTextView.append(testScores.getString(2)+" - "+testScores.getString(1)+", "+testScores.getString(3)+"\n");
            }
        }
        if(classes.getCount() == 0){
            ClassesTextView.setText("N/A");
        }else{
            while(classes.moveToNext()){
                ClassesTextView.append(classes.getString(2)+" - "+classes.getString(1)+" - "+classes.getString(3)+"\n");
            }
        }
        if(work.getCount() == 0){
            WorkExperienceTextView.setText("N/A");
        }else{
            while(work.moveToNext()){
                WorkExperienceTextView.append(work.getString(3) + "\n" + work.getString(1) + "-" + work.getString(2) + ", " + work.getString(5) + ", " + work.getString(6) + "\n" + work.getString(4) + "\n");
            }
        }
        if(volunteer.getCount() == 0){
            VolunteerExperienceTextView.setText("N/A");
        }else{
            while(volunteer.moveToNext()){
                VolunteerExperienceTextView.append(volunteer.getString(1) + "\n" + volunteer.getString(2) + "-" + volunteer.getString(4) + "hours" + "\n" + volunteer.getString(3) + "\n");
            }
        }
        if(extracurricular.getCount() == 0){
            ExtracurricularsTextView.setText("N/A");
        }else{
            while(extracurricular.moveToNext()){
                ExtracurricularsTextView.append(extracurricular.getString(3) + "\n" + extracurricular.getString(1) + "-" + extracurricular.getString(2) + "\n" + extracurricular.getString(4) + "\n");
            }
        }
        if(clubs.getCount() == 0){
            ClubsTextView.setText("N/A");
        }else{
            while(clubs.moveToNext()){
                ClubsTextView.append(clubs.getString(3) + "\n" + clubs.getString(1) + "-" + clubs.getString(2) + "\n" + clubs.getString(4) + "\n");
            }
        }
        export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convertXMLtoPDF();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareActivityScreenshot();
            }
        });

    }
    private void convertXMLtoPDF(){

        DisplayMetrics displayMetrics = new DisplayMetrics();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            this.getDisplay().getRealMetrics(displayMetrics);
        }
        else this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        View view = this.findViewById(android.R.id.content);
        view.measure(View.MeasureSpec.makeMeasureSpec(displayMetrics.widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(displayMetrics.heightPixels,View.MeasureSpec.EXACTLY));
        int[] outLoc = new int[2];
        export.getLocationOnScreen(outLoc);
        int viewWidth = view.getMeasuredWidth();
        int viewHeight = outLoc[1]-60;
        view.layout(0,0,displayMetrics.widthPixels,displayMetrics.heightPixels);
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(viewWidth, viewHeight,1).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        view.draw(canvas);
        document.finishPage(page);
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String fileName = name+".pdf";
        File file = new File(downloadsDir, fileName);
        try{
            FileOutputStream fos = new FileOutputStream(file);
            document.writeTo(fos);
            document.close();
            Toast.makeText(this, "Export Success!", Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void askPermissions(){
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
    }
    public void shareActivityScreenshot() {
        View view = this.findViewById(android.R.id.content);
        int[] outLoc = new int[2];
        export.getLocationOnScreen(outLoc);
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), outLoc[1]-60, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        // Save the bitmap to a file
        File file = new File(getExternalCacheDir(), "screenshot.png");
        try {
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Share the image using an intent
        shareImage(file);
    }
    private void shareImage(File imageFile) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        Uri imageUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", imageFile);
        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, name+"'s MyBackpack Resume");
        startActivity(Intent.createChooser(shareIntent, "Share image"));
    }
}