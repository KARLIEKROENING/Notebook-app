package com.example.fblaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter10 extends RecyclerView.Adapter<CustomAdapter10.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, datelst, gradelst;
    CustomAdapter10(Context context, ArrayList namelst, ArrayList datelst, ArrayList gradelst){
        this.context = context;
        this.namelst = namelst;
        this.datelst = datelst;
        this.gradelst = gradelst;
    }

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row8,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter10.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.dateid.setText(String.valueOf(datelst.get(position)));
        holder.gradeid.setText(String.valueOf(gradelst.get(position)));
    }

    @Override
    public int getItemCount() {
        return datelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameid, dateid, gradeid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameid = itemView.findViewById(R.id.nameid);
            dateid = itemView.findViewById(R.id.dateid);
            gradeid = itemView.findViewById(R.id.gradeid);

        }

    }
}
