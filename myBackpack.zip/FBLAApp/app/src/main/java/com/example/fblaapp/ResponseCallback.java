package com.example.fblaapp;

public interface ResponseCallback {
    void onResponse(String response);
    void onError(Throwable throwable);
}
