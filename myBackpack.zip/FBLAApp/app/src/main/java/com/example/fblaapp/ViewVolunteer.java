package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewVolunteer extends AppCompatActivity {

    DatabaseHelper DB;
    Button addVolunteer;
    ArrayList<String> datelst, organizationlst, descriptionlst, hourslst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_volunteer);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addVolunteer = findViewById(R.id.addVolunteer);
        addVolunteer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editVolunteerPage = new Intent(ViewVolunteer.this, AddVolunteer.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editVolunteerPage.putExtras(b);
                startActivity(editVolunteerPage);
            }
        });
        datelst = new ArrayList<>();
        organizationlst = new ArrayList<>();
        descriptionlst = new ArrayList<>();
        hourslst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter6 customAdapter1 = new CustomAdapter6(ViewVolunteer.this, datelst, organizationlst, descriptionlst, hourslst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewVolunteer.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllVolunteer(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                datelst.add(cursor.getString(1));
                organizationlst.add(cursor.getString(2));
                descriptionlst.add(cursor.getString(3));
                hourslst.add(cursor.getString(4));
            }
        }
    }
}