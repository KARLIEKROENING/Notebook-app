package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Calendar;
import java.text.SimpleDateFormat;

// This class extends AppCompatActivity and represents the activity for creating a new event.
public class AddVolunteer extends AppCompatActivity {
    private EditText etSelectDateStarted, etSelectDateEnded, etOrganization, etDescription, etHours;
    private Button createButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getExtras();
        String name = b.getString("name");
        setContentView(R.layout.activity_add_volunteer);
        etSelectDateStarted = findViewById(R.id.SelectDateIdStarted);
        etSelectDateEnded = findViewById(R.id.SelectDateIdEnded);
        etOrganization = findViewById(R.id.organizationid);
        etDescription = findViewById(R.id.descriptionid);
        etHours = findViewById(R.id.hoursid);
        createButton = findViewById(R.id.AddVolunteer);
        etSelectDateEnded.addTextChangedListener(loginTextWatcher);
        etSelectDateStarted.addTextChangedListener(loginTextWatcher);
        etOrganization.addTextChangedListener(loginTextWatcher);
        etDescription.addTextChangedListener(loginTextWatcher);
        etHours.addTextChangedListener(loginTextWatcher);
        DatabaseHelper DB = new DatabaseHelper(this);
        final Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        etSelectDateStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog = new DatePickerDialog(AddVolunteer.this, R.style.TimePickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        i1 = i1 + 1;
                        String date = ""+i + String.format("%02d", i1) + String.format("%02d", i2);

                        etSelectDateStarted.setText(formatDate(date));

                    }
                }, year, month, day);
                dialog.show();
            }
        });
        etSelectDateEnded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dialog = new DatePickerDialog(AddVolunteer.this, R.style.TimePickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        i1 = i1 + 1;
                        String date = ""+i + String.format("%02d", i1) + String.format("%02d", i2);

                        etSelectDateEnded.setText(formatDate(date));

                    }
                }, year, month, day);
                dialog.show();
            }
        });
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String DateDuration = etSelectDateStarted.getText().toString()+"-"+etSelectDateEnded.getText().toString();
                String Organization = etOrganization.getText().toString();
                String Description = etDescription.getText().toString();
                String Hours = etHours.getText().toString();
                Boolean checkinsertdata = DB.insertVolunteerData(name, DateDuration, Organization, Description, Hours);
                if (checkinsertdata == true) {
                    Toast.makeText(AddVolunteer.this, "Award Creation Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddVolunteer.this, "Award Creation Failed", Toast.LENGTH_SHORT).show();
                }
                Intent editAwardsPage = new Intent(AddVolunteer.this, TeacherHome.class);
                Bundle b = new Bundle();
                b.putString("username", DB.getDataUserName(name));
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String SelectDate = etSelectDateEnded.getText().toString().trim();
            String SelectDate1 = etSelectDateStarted.getText().toString().trim();
            String Desc = etDescription.getText().toString().trim();
            String Hrs = etHours.getText().toString().trim();
            String Organization = etOrganization.getText().toString().trim();
            createButton.setEnabled(!SelectDate.isEmpty() && !SelectDate1.isEmpty() &&!Desc.isEmpty()&& !Hrs.isEmpty() && !Organization.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
    public static String formatDate(String dateString) {
        if (dateString.length() != 8) {
            throw new IllegalArgumentException("Invalid date format. Please provide a string in the format YYYYMMDD.");
        }

        int year = Integer.parseInt(dateString.substring(0, 4));
        int month = Integer.parseInt(dateString.substring(4, 6));
        int day = Integer.parseInt(dateString.substring(6));

        return String.format("%d/%d/%d", month, day, year);
    }

}

