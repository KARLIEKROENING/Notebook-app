package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewWorkExperience extends AppCompatActivity {

    DatabaseHelper DB;
    Button addWork;
    ArrayList<String> namelst, positionlst, datelst, descriptionlst, typelst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_work_experience);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addWork = findViewById(R.id.addWork);
        addWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editWorkPage = new Intent(ViewWorkExperience.this, AddWorkExperience.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editWorkPage.putExtras(b);
                startActivity(editWorkPage);
            }
        });
        namelst = new ArrayList<>();
        positionlst = new ArrayList<>();
        datelst = new ArrayList<>();
        descriptionlst = new ArrayList<>();
        typelst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter9 customAdapter1 = new CustomAdapter9(ViewWorkExperience.this, namelst, positionlst, datelst, descriptionlst, typelst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewWorkExperience.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllWork(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                positionlst.add(cursor.getString(2));
                datelst.add(cursor.getString(3));
                descriptionlst.add(cursor.getString(4));
                typelst.add(cursor.getString(5)+", "+cursor.getString(6));
            }
        }
    }
}