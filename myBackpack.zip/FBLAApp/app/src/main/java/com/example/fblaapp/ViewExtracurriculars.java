package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewExtracurriculars extends AppCompatActivity {

    DatabaseHelper DB;
    Button addEC;
    ArrayList<String> namelst, positionlst, datelst, descriptionlst;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_extracurriculars);
        DB = new DatabaseHelper(this);
        Bundle b = getIntent().getExtras();
        name = b.getString("name");
        addEC = findViewById(R.id.addEC);
        addEC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editVolunteerPage = new Intent(ViewExtracurriculars.this, AddExtracurriculars.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                editVolunteerPage.putExtras(b);
                startActivity(editVolunteerPage);
            }
        });
        namelst = new ArrayList<>();
        positionlst = new ArrayList<>();
        datelst = new ArrayList<>();
        descriptionlst = new ArrayList<>();
        storeDataInArrays1();
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        CustomAdapter8 customAdapter1 = new CustomAdapter8(ViewExtracurriculars.this, namelst, positionlst, datelst, descriptionlst);
        recyclerView.setAdapter(customAdapter1);
        recyclerView.setLayoutManager(new LinearLayoutManager(ViewExtracurriculars.this));

    }
    void storeDataInArrays1(){
        Cursor cursor = DB.getDataNameAllExtracurriculars(name);
        if(cursor.getCount() == 0){
            Toast.makeText(this,"No data", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                namelst.add(cursor.getString(1));
                positionlst.add(cursor.getString(2));
                datelst.add(cursor.getString(3));
                descriptionlst.add(cursor.getString(4));
            }
        }
    }
}