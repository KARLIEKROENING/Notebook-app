package com.example.fblaapp;

import java.util.ArrayList;

public interface QuantityListener {
    void onQuantityChange(ArrayList<String> students);
}
