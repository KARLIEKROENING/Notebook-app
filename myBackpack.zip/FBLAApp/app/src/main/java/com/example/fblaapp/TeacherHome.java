package com.example.fblaapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Random;

import java.util.ArrayList;
import java.util.HashMap;

public class TeacherHome extends AppCompatActivity {
    final static int REQUEST_CODE = 1232;
    Button viewProfiles, viewClasses, viewVolunteerExperience, viewClubs, viewExtracurriculars, viewWorkExperience, viewAwardsHonors, viewTestScores, viewMyProfile, signOut, help, bugReporting, viewMyAccount;
    TextView tv1;
    ArrayList<String> NameLst;
    DatabaseHelper DB;
    Bundle b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_home);
        NameLst = new ArrayList<String>();
        b = getIntent().getExtras();
        String username = b.getString("username");
        viewProfiles = findViewById(R.id.ViewProfiles);
        viewClasses = findViewById(R.id.ViewClasses);
        viewVolunteerExperience = findViewById(R.id.ViewVolunteerExperience);
        viewClubs = findViewById(R.id.ViewClubs);
        viewExtracurriculars = findViewById(R.id.ViewExtracurriculars);
        viewWorkExperience = findViewById(R.id.ViewWorkExperience);
        viewAwardsHonors = findViewById(R.id.ViewAwardsAndHonors);
        viewTestScores = findViewById(R.id.ViewTestScores);
        viewMyProfile = findViewById(R.id.ViewMyProfile);
        bugReporting = findViewById(R.id.BugReporting);
        viewMyAccount = findViewById(R.id.MyAccount);
        help = findViewById(R.id.Help);
        DB = new DatabaseHelper(this);
        signOut = findViewById(R.id.SignOut);
        tv1 = findViewById(R.id.TV1);
        String name = DB.getDataName(username);
        Log.d("the name is", name);
        tv1.setText("Hi " + name.split("\\s+")[0] + "!👋");
        viewProfiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ViewProfiles = new Intent(TeacherHome.this, com.example.fblaapp.ViewStudents.class);
                startActivity(ViewProfiles);

            }
        });
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainPage = new Intent(TeacherHome.this, MainActivity.class);
                startActivity(mainPage);
            }
        });
        viewVolunteerExperience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ViewVolunteerExperience = new Intent(TeacherHome.this, ViewVolunteer.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                ViewVolunteerExperience.putExtras(b);
                startActivity(ViewVolunteerExperience);
            }
        });
        viewClubs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewClubs = new Intent(TeacherHome.this, ViewClubs.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewClubs.putExtras(b);
                startActivity(viewClubs);
            }
        });
        viewExtracurriculars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewExtracurriculars = new Intent(TeacherHome.this, ViewExtracurriculars.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewExtracurriculars.putExtras(b);
                startActivity(viewExtracurriculars);
            }
        });
        viewAwardsHonors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewAwardsHonors = new Intent(TeacherHome.this, ViewAwards.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewAwardsHonors.putExtras(b);
                startActivity(viewAwardsHonors);
            }
        });
        viewWorkExperience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewWorkExperience = new Intent(TeacherHome.this, ViewWorkExperience.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewWorkExperience.putExtras(b);
                startActivity(viewWorkExperience);
            }
        });
        viewClasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewClasses = new Intent(TeacherHome.this, ViewClasses.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewClasses.putExtras(b);
                startActivity(viewClasses);
            }
        });
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent help = new Intent(TeacherHome.this, Help.class);
                startActivity(help);
            }
        });
        viewTestScores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewTestScores = new Intent(TeacherHome.this, ViewTestScores.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewTestScores.putExtras(b);
                startActivity(viewTestScores);
            }
        });
        viewMyProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewMyProfile = new Intent(TeacherHome.this, ViewProfile.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewMyProfile.putExtras(b);
                startActivity(viewMyProfile);
            }
        });
        viewMyAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewMyAccount = new Intent(TeacherHome.this, ViewMyAccount.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                viewMyAccount.putExtras(b);
                startActivity(viewMyAccount);
            }
        });
        bugReporting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent bugReporting = new Intent(TeacherHome.this, BugReport.class);
                Bundle b = new Bundle();
                b.putString("name", name);
                bugReporting.putExtras(b);
                startActivity(bugReporting);
            }
        });


    }
}