package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class CreateAccPage extends AppCompatActivity {
    //initialize variables
    private EditText EmailAddressInput;
    private EditText NameInput;
    private EditText UsernameInput;
    private EditText PasswordInput;
    private EditText GradeInput;

    private EditText SchoolInput;
    private Button SignUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acc_page);
        //initialize dropdown menu, buttons, and inputs
        EmailAddressInput = findViewById(R.id.EmailAddress);
        NameInput = findViewById(R.id.Name);
        UsernameInput = findViewById(R.id.Username);
        PasswordInput = findViewById(R.id.Password);
        GradeInput = findViewById(R.id.Grade);
        SchoolInput = findViewById(R.id.School);
        EmailAddressInput.addTextChangedListener(signupTextWatcher);
        NameInput.addTextChangedListener(signupTextWatcher);
        UsernameInput.addTextChangedListener(signupTextWatcher);
        PasswordInput.addTextChangedListener(signupTextWatcher);
        GradeInput.addTextChangedListener(signupTextWatcher);
        SchoolInput.addTextChangedListener((signupTextWatcher));
        SignUp = findViewById(R.id.SignUp);
        //initialize database and array adapter for use in the dropdown menu
        DatabaseHelper DB = new DatabaseHelper(this);

        ;
        //when the sign up button is clicked add all the data contained within each edittext into the database
        SignUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String email = EmailAddressInput.getText().toString();
                String name = NameInput.getText().toString();
                String username = UsernameInput.getText().toString();
                String password = PasswordInput.getText().toString();
                String grade = GradeInput.getText().toString();
                String school = SchoolInput.getText().toString();
                Boolean checkinsertdata = DB.insertuserdata(email, name, username, password, grade, school);
                    // if successful bring user back into home page
                    if(checkinsertdata == true) {
                        Intent Home = new Intent(CreateAccPage.this, MainActivity.class);
                        startActivity(Home);
                    }
                    //otherwise show message that username is already in use
                    else{
                        UsernameInput.setError("This username is already in use.");
                    }
            }
        });


    }
    //method to check if any text fields are empty, if so disable button to create
    private TextWatcher signupTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String emailAddInput = EmailAddressInput.getText().toString().trim();
            String nameInput = NameInput.getText().toString().trim();
            String usernameInput = UsernameInput.getText().toString().trim();
            String passwordInput = PasswordInput.getText().toString().trim();
            String gradeInput = GradeInput.getText().toString().trim();
            String schoolInput = SchoolInput.getText().toString().trim();
            SignUp.setEnabled(!emailAddInput.isEmpty() && !nameInput.isEmpty() &&!usernameInput.isEmpty() &&!passwordInput.isEmpty() &&!gradeInput.isEmpty() &&!schoolInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };

}