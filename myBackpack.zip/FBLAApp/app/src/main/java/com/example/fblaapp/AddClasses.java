package com.example.fblaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.Calendar;
import java.text.SimpleDateFormat;

// This class extends AppCompatActivity and represents the activity for creating a new event.
public class AddClasses extends AppCompatActivity {
    private EditText etName, etGrade, etYear;
    private Button createButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getExtras();
        String name = b.getString("name");
        setContentView(R.layout.activity_add_classes);
        etName = findViewById(R.id.ClassName);
        etGrade = findViewById(R.id.Grade);
        etYear = findViewById(R.id.YearTaken);
        createButton = findViewById(R.id.AddClass);
        etName.addTextChangedListener(loginTextWatcher);
        etGrade.addTextChangedListener(loginTextWatcher);
        etYear.addTextChangedListener(loginTextWatcher);
        DatabaseHelper DB = new DatabaseHelper(this);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ClassName = etName.getText().toString();
                String GradeReceived = etGrade.getText().toString();
                String YearTaken = etYear.getText().toString();
                Boolean checkinsertdata = DB.insertClassesData(name, ClassName, YearTaken, GradeReceived);
                if (checkinsertdata == true) {
                    Toast.makeText(AddClasses.this, "Class Creation Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddClasses.this, "Class Creation Failed", Toast.LENGTH_SHORT).show();
                }
                Intent editAwardsPage = new Intent(AddClasses.this, TeacherHome.class);
                Bundle b = new Bundle();
                b.putString("username", DB.getDataUserName(name));
                editAwardsPage.putExtras(b);
                startActivity(editAwardsPage);
            }
        });
    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String SelectDate = etGrade.getText().toString().trim();
            String EventName = etYear.getText().toString().trim();
            String EventDuration = etName.getText().toString().trim();
            createButton.setEnabled(!SelectDate.isEmpty() && !EventName.isEmpty()&& !EventDuration.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }

    };
}

