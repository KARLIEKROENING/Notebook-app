package com.example.fblaapp;

import androidx.core.content.FileProvider;

public class MyFileProvider extends FileProvider {

}
