package com.example.fblaapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class CustomAdapter1 extends RecyclerView.Adapter<CustomAdapter1.MyViewHolder> {
    @NonNull
    Context context;
    ArrayList namelst, gradelst;
    DatabaseHelper DB;
    Button button;
    CustomAdapter1(Context context, ArrayList namelst, ArrayList gradelst){
        this.context = context;
        this.namelst = namelst;
        this.gradelst = gradelst;

    }
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row1,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter1.MyViewHolder holder, int position) {
        holder.nameid.setText(String.valueOf(namelst.get(position)));
        holder.gradeid.setText(String.valueOf(gradelst.get(position)));
    }

    @Override
    public int getItemCount() {
        return namelst.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameid, gradeid;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameid = itemView.findViewById(R.id.nameid);
            gradeid = itemView.findViewById(R.id.gradeid);
            itemView.findViewById(R.id.ViewProfileButton).setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    Bundle b = new Bundle();
                    Intent intent = new Intent(context, ViewProfile.class);
                    b.putString("name", nameid.getText().toString());
                    intent.putExtras(b);
                    context.startActivity(intent);
                }
            });
        }

    }
    public void clear() {
        int size = namelst.size();
        namelst.clear();
        gradelst.clear();
        notifyItemRangeRemoved(0, size);
    }
}
